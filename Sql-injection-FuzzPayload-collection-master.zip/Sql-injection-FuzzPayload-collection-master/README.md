# Sql-injection-FuzzPayload-collection
Sql-injection FuzzPayload collection:Sql-injection FuzzPayload 集合

开源信息搜集，只做测试使用，无攻击性行为。请使用者遵守《中华人民共和国网络安全法》，勿将此信息用于非授权的测试，本组织不负任何连带法律责任。
本声明未涉及的问题参见国家有关法律法规，当本声明与国家法律法规冲突时，以国家法律法规为准。

Open source information collection, only test use, no aggressive behavior. Please use the Internet Security Law of the People 's Republic of China and do not use this information for unauthorized testing. The organization shall not be liable for any joint and several liability.
